import { supabase } from "../../../lib/supabase";
import { getBusinessId, getSettingRow } from "./settings.service";
import type { BusinessSettingsUpdate } from "../types/business-settings";
export type BusinessSettings = { business_id:string; business_phone:string|null; business_email:string|null; city:string|null; address:string|null; latitude:number|null; longitude:number|null; is_published:boolean; is_temporarily_closed:boolean; temporary_close_reason:string|null; created_at?:string; updated_at?:string };
const DEFAULTS={business_phone:null,business_email:null,city:null,address:null,latitude:null,longitude:null,is_published:false,is_temporarily_closed:false,temporary_close_reason:null};
export const businessSettingsService={
 async get():Promise<BusinessSettings>{const business_id=await getBusinessId();const data=await getSettingRow("business_settings",business_id);if(data)return data as BusinessSettings;return this.save(DEFAULTS);},
 async save(values:BusinessSettingsUpdate):Promise<BusinessSettings>{const business_id=await getBusinessId();const {data,error}=await supabase.from("business_settings").upsert({business_id,...values,updated_at:new Date().toISOString()},{onConflict:"business_id"}).select("*").single();if(error)throw new Error(`Failed to save business settings: ${error.message}`);return data as BusinessSettings;},
 setPublished(published:boolean){return this.save({is_published:published});},
 setTemporarilyClosed(closed:boolean,reason:string|null=null){return this.save({is_temporarily_closed:closed,temporary_close_reason:closed?reason:null});}
};
export const getBusinessSettings=businessSettingsService.get;export const updateBusinessSettings=businessSettingsService.save;
