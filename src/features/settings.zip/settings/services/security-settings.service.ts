import { supabase } from "../../../lib/supabase";

async function hashPasskey(passkey: string) {
  const bytes = new TextEncoder().encode(passkey);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

export const securitySettingsService = {
  async getUser() {
    const { data, error } = await supabase.auth.getUser();
    if (error) throw error;
    if (!data.user) throw new Error("User not authenticated");
    return data.user;
  },

  async changePassword(password: string) {
    if (password.length < 8) throw new Error("Password must be at least 8 characters");
    const { error } = await supabase.auth.updateUser({ password });
    if (error) throw error;
  },

  async changeEmail(email: string) {
    const normalized = email.trim().toLowerCase();
    if (!normalized) throw new Error("Email is required");
    const { error } = await supabase.auth.updateUser({ email: normalized });
    if (error) throw error;
  },

  async updateMetadata(values: Record<string, unknown>) {
    const user = await this.getUser();
    const { data, error } = await supabase.auth.updateUser({
      data: { ...user.user_metadata, ...values },
    });
    if (error) throw error;
    return data.user;
  },

  async setPasskey(passkey: string) {
    const value = passkey.trim();
    if (value.length < 6) throw new Error("Passkey must be at least 6 characters.");
    const hash = await hashPasskey(value);
    await this.updateMetadata({
      settings_passkey_hash: hash,
      settings_passkey_enabled: true,
    });
  },

  async hasPasskey() {
    const user = await this.getUser();
    return user.user_metadata?.settings_passkey_enabled === true &&
      typeof user.user_metadata?.settings_passkey_hash === "string";
  },

  async verifyPasskey(passkey: string) {
    const user = await this.getUser();
    const expected = user.user_metadata?.settings_passkey_hash;
    if (typeof expected !== "string") {
      throw new Error("No danger-zone passkey is configured. Set one in Security first.");
    }
    return (await hashPasskey(passkey.trim())) === expected;
  },

  async clearPasskey() {
    await this.updateMetadata({
      settings_passkey_hash: null,
      settings_passkey_enabled: false,
    });
  },

  async logoutCurrentDevice() {
    const { error } = await supabase.auth.signOut({ scope: "local" });
    if (error) throw error;
  },

  async logoutEverywhere() {
    const { error } = await supabase.auth.signOut({ scope: "global" });
    if (error) throw error;
  },
};
