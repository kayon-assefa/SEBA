import { useEffect, useState } from "react";
import { SettingsCard, SettingsInput, SettingsButton } from "../components";
import { securitySettingsService } from "../services/security-settings.service";

export default function SecuritySection() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [passkey, setPasskey] = useState("");
  const [hasPasskey, setHasPasskey] = useState(false);
  const [msg, setMsg] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    Promise.all([securitySettingsService.getUser(), securitySettingsService.hasPasskey()])
      .then(([user, enabled]) => {
        setEmail(user.email ?? "");
        setHasPasskey(enabled);
      })
      .catch((e) => setMsg(e.message));
  }, []);

  const passwordSave = async () => {
    if (password !== confirm) return setMsg("Passwords do not match");
    setSaving(true); setMsg("");
    try {
      await securitySettingsService.changePassword(password);
      setPassword(""); setConfirm(""); setMsg("Password updated.");
    } catch (e) { setMsg(e instanceof Error ? e.message : "Failed"); }
    finally { setSaving(false); }
  };

  const emailSave = async () => {
    setSaving(true); setMsg("");
    try {
      await securitySettingsService.changeEmail(email);
      setMsg("Confirmation email sent if email confirmation is enabled.");
    } catch (e) { setMsg(e instanceof Error ? e.message : "Failed"); }
    finally { setSaving(false); }
  };

  const savePasskey = async () => {
    setSaving(true); setMsg("");
    try {
      await securitySettingsService.setPasskey(passkey);
      setPasskey(""); setHasPasskey(true); setMsg("Danger-zone passkey enabled.");
    } catch (e) { setMsg(e instanceof Error ? e.message : "Failed"); }
    finally { setSaving(false); }
  };

  const removePasskey = async () => {
    setSaving(true); setMsg("");
    try {
      await securitySettingsService.clearPasskey();
      setHasPasskey(false); setMsg("Danger-zone passkey removed.");
    } catch (e) { setMsg(e instanceof Error ? e.message : "Failed"); }
    finally { setSaving(false); }
  };

  return (
    <div className="space-y-6">
      <SettingsCard title="Password">
        <div className="grid gap-4 md:grid-cols-2">
          <SettingsInput label="New password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
          <SettingsInput label="Confirm password" type="password" value={confirm} onChange={(e) => setConfirm(e.target.value)} />
        </div>
        <div className="mt-4"><SettingsButton onClick={passwordSave} loading={saving}>Change password</SettingsButton></div>
      </SettingsCard>

      <SettingsCard title="Email" description="Change your login email directly from settings. Supabase may require confirmation.">
        <SettingsInput label="Account email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
        <div className="mt-4"><SettingsButton onClick={emailSave} loading={saving}>Send email change</SettingsButton></div>
      </SettingsCard>

      <SettingsCard title="Danger-zone passkey" description="A passkey is required before destructive actions in Danger Zone.">
        <div className="flex flex-wrap items-center gap-3">
          <span className={hasPasskey ? "text-sm text-green-700" : "text-sm text-gray-500"}>
            {hasPasskey ? "Passkey enabled" : "No passkey configured"}
          </span>
        </div>
        <div className="mt-4 max-w-md">
          <SettingsInput label={hasPasskey ? "Replace passkey" : "Create passkey"} type="password" value={passkey} onChange={(e) => setPasskey(e.target.value)} />
        </div>
        <div className="mt-4 flex gap-3">
          <SettingsButton onClick={savePasskey} loading={saving}>Save passkey</SettingsButton>
          {hasPasskey && <SettingsButton variant="secondary" onClick={removePasskey} loading={saving}>Remove passkey</SettingsButton>}
        </div>
      </SettingsCard>

      <SettingsCard title="Sessions">
        <div className="flex flex-wrap gap-3">
          <SettingsButton variant="secondary" onClick={() => securitySettingsService.logoutCurrentDevice()}>Log out this device</SettingsButton>
          <SettingsButton variant="danger" onClick={() => securitySettingsService.logoutEverywhere()}>Log out all devices</SettingsButton>
        </div>
      </SettingsCard>

      {msg && <p className="text-sm text-gray-600">{msg}</p>}
    </div>
  );
}
