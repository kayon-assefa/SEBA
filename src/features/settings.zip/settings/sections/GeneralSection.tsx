import { useEffect, useState } from "react";
import { SettingsCard, SettingsInput, SettingsSelect, SettingsButton, ImageUpload } from "../components";
import { securitySettingsService } from "../services/security-settings.service";
import { uploadCompanyImage } from "../services/settings.service";

export default function GeneralSection() {
  const [user, setUser] = useState<any>(null);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [language, setLanguage] = useState("en");
  const [currency, setCurrency] = useState("ETB");
  const [timezone, setTimezone] = useState("Africa/Addis_Ababa");
  const [calendar, setCalendar] = useState("gregorian");
  const [companyImage, setCompanyImage] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState("");

  useEffect(() => {
    securitySettingsService.getUser().then((u) => {
      setUser(u);
      setName(u.user_metadata?.full_name ?? u.user_metadata?.name ?? "");
      setEmail(u.email ?? "");
      setLanguage(u.user_metadata?.language ?? "en");
      setCurrency(u.user_metadata?.currency ?? "ETB");
      setTimezone(u.user_metadata?.timezone ?? "Africa/Addis_Ababa");
      setCalendar(u.user_metadata?.calendar ?? "gregorian");
      setCompanyImage(u.user_metadata?.company_image_url ?? null);
    }).catch((e) => setMsg(e.message));
  }, []);

  const save = async () => {
    setSaving(true);
    setMsg("");
    try {
      const updated = await securitySettingsService.updateMetadata({
        full_name: name,
        name,
        language,
        currency,
        timezone,
        calendar,
        company_image_url: companyImage,
      });

      if (email.trim().toLowerCase() !== (user?.email ?? "").toLowerCase()) {
        await securitySettingsService.changeEmail(email);
      }

      setUser(updated);
      setMsg("Saved");
    } catch (e) {
      setMsg(e instanceof Error ? e.message : "Failed to save");
    } finally {
      setSaving(false);
    }
  };

  const onImage = async (file: File | null) => {
    if (!file) {
      setCompanyImage(null);
      return;
    }
    try {
      setMsg("Uploading image…");
      const url = await uploadCompanyImage(file);
      setCompanyImage(url);
      setMsg("Image uploaded. Save profile to keep it on your account.");
    } catch (e) {
      setMsg(e instanceof Error ? e.message : "Image upload failed");
    }
  };

  return (
    <div className="space-y-6">
      <SettingsCard title="Profile" description="Your SEBA account profile.">
        <div className="grid gap-5 md:grid-cols-[220px_minmax(0,1fr)]">
          <ImageUpload label="Company image" value={companyImage} onChange={onImage} />
          <div className="grid gap-4">
            <SettingsInput label="Profile name" value={name} onChange={(e) => setName(e.target.value)} />
            <SettingsInput label="Email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
          </div>
        </div>
        <div className="mt-5 flex items-center gap-3">
          <SettingsButton onClick={save} loading={saving}>Save profile</SettingsButton>
          {msg && <span className="text-sm text-gray-600">{msg}</span>}
        </div>
      </SettingsCard>

      <SettingsCard title="Language" description="Choose the language used by your dashboard.">
        <SettingsSelect label="Language" value={language} onChange={(e) => setLanguage(e.target.value)} options={[
          { label: "English", value: "en" }, { label: "አማርኛ", value: "am" }, { label: "Afaan Oromoo", value: "om" },
        ]} />
        <div className="mt-4"><SettingsButton onClick={save} loading={saving}>Save language</SettingsButton></div>
      </SettingsCard>

      <SettingsCard title="Region" description="Configure your regional preferences.">
        <div className="grid gap-4 md:grid-cols-2">
          <SettingsInput label="Country" value="Ethiopia" disabled />
          <SettingsSelect label="Currency" value={currency} onChange={(e) => setCurrency(e.target.value)} options={[
            { label: "ETB — Ethiopian Birr", value: "ETB" }, { label: "USD — US Dollar", value: "USD" },
          ]} />
          <SettingsSelect label="Timezone" value={timezone} onChange={(e) => setTimezone(e.target.value)} options={[
            { label: "Africa/Addis_Ababa", value: "Africa/Addis_Ababa" },
          ]} />
          <SettingsSelect label="Calendar" value={calendar} onChange={(e) => setCalendar(e.target.value)} options={[
            { label: "Gregorian", value: "gregorian" }, { label: "Ethiopian", value: "ethiopian" },
          ]} />
        </div>
        <div className="mt-4"><SettingsButton onClick={save} loading={saving}>Save preferences</SettingsButton></div>
      </SettingsCard>
    </div>
  );
}
