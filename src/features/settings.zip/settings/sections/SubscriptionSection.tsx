import { useEffect, useState } from "react";
import { SettingsCard } from "../components";
import { subscriptionSettingsService } from "../services/subscription-settings.service";

function date(value: string | null | undefined) {
  if (!value) return "—";
  return new Intl.DateTimeFormat("en-GB", { dateStyle: "medium" }).format(new Date(value));
}

export default function SubscriptionSection() {
  const [ctx, setCtx] = useState<any>(null);
  const [msg, setMsg] = useState("");

  useEffect(() => {
    subscriptionSettingsService.getContext()
      .then(setCtx)
      .catch((e) => setMsg(e.message));
  }, []);

  if (!ctx) return <div className="p-6 text-sm text-gray-500">{msg || "Loading subscription…"}</div>;

  const sub = ctx.subscription;
  const trialEnded = ctx.trialEnded;
  const status = trialEnded ? "free trial ended" : sub.status;

  return (
    <div className="space-y-6">
      <SettingsCard title="Your subscription" description="Subscription status is calculated from your account and the subscription record in Supabase.">
        <div className="rounded-2xl border p-5">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <p className="text-sm text-gray-500">Current plan</p>
              <h3 className="mt-1 text-2xl font-bold capitalize">{sub.plan}</h3>
            </div>
            <span className={[
              "rounded-full px-3 py-1 text-xs font-semibold",
              trialEnded ? "bg-red-100 text-red-700" : "bg-gray-100 text-gray-700",
            ].join(" ")}>
              {status}
            </span>
          </div>

          <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <div><p className="text-xs text-gray-500">Trial / start</p><p className="mt-1 font-medium">{date(sub.trial_start ?? sub.start_date)}</p></div>
            <div><p className="text-xs text-gray-500">Trial / end</p><p className="mt-1 font-medium">{date(sub.trial_end ?? sub.end_date)}</p></div>
            <div><p className="text-xs text-gray-500">Price</p><p className="mt-1 font-medium">{sub.price ? `${sub.price} ${sub.currency ?? "ETB"}` : "Free trial"}</p></div>
            <div><p className="text-xs text-gray-500">Next billing</p><p className="mt-1 font-medium">{date(sub.next_billing_date)}</p></div>
          </div>

          {trialEnded && (
            <div className="mt-5 rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">
              Your 14-day free trial has ended. The public page should remain unavailable until an active paid subscription is set.
            </div>
          )}
        </div>
      </SettingsCard>

      <SettingsCard title="Plans" description="Pricing configured for SEBA.">
        <div className="grid gap-4 md:grid-cols-3">
          {ctx.plans.map((plan: any) => (
            <div key={plan.id} className={[
              "rounded-2xl border p-5",
              plan.id === sub.plan ? "border-gray-900 ring-1 ring-gray-900" : "border-gray-200",
            ].join(" ")}>
              <p className="text-sm text-gray-500">{plan.name}</p>
              <p className="mt-2 text-3xl font-bold">{plan.price} <span className="text-sm font-medium">ETB / month</span></p>
              <p className="mt-2 text-sm text-gray-500">{plan.description}</p>
              <ul className="mt-4 space-y-2 text-sm">
                {plan.features.map((feature: string) => <li key={feature}>✓ {feature}</li>)}
              </ul>
            </div>
          ))}
        </div>
      </SettingsCard>
    </div>
  );
}
