import { useEffect, useState } from "react";
import { SettingsCard, SettingsToggle, SettingsButton } from "../components";
import { notificationSettingsService } from "../services/notification-settings.service";

const EVENTS = [
  "new_appointment_email", "appointment_confirmation_email", "appointment_reminder_email",
  "new_order_email", "new_customer_email", "low_stock_email", "trial_ending_email", "payment_due_email",
];

export default function NotificationSection() {
  const [s, setS] = useState<any>(null);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState("");

  useEffect(() => {
    notificationSettingsService.get()
      .then((x) => setS(x ?? {}))
      .catch((e) => setMsg(e.message));
  }, []);

  if (!s) return <div className="p-6 text-sm text-gray-500">{msg || "Loading…"}</div>;

  const set = (key: string, value: boolean) => setS((x: any) => ({ ...x, [key]: value }));

  const save = async () => {
    setSaving(true);
    setMsg("");
    try {
      setS(await notificationSettingsService.save(s));
      setMsg("Saved");
    } catch (e) {
      setMsg(e instanceof Error ? e.message : "Failed to save");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <SettingsCard title="Notification channels">
        <div className="space-y-4">
          <SettingsToggle label="Email" checked={s.email_enabled !== false} onChange={(v) => set("email_enabled", v)} />
          <SettingsToggle label="Push notifications" checked={!!s.push_enabled} onChange={(v) => set("push_enabled", v)} />
          <div className="flex items-center justify-between rounded-xl border border-gray-200 p-4">
            <div>
              <p className="font-medium text-gray-900">SMS</p>
              <p className="text-sm text-gray-500">SMS notifications are coming soon.</p>
            </div>
            <span className="rounded-full bg-gray-100 px-3 py-1 text-xs font-semibold text-gray-500">Coming soon</span>
          </div>
        </div>
      </SettingsCard>

      <SettingsCard title="Email events">
        <div className="space-y-4">
          {EVENTS.map((key) => (
            <SettingsToggle
              key={key}
              label={key.replaceAll("_", " ")}
              checked={!!s[key]}
              onChange={(v) => set(key, v)}
            />
          ))}
        </div>
        <div className="mt-4 flex items-center gap-3">
          <SettingsButton onClick={save} loading={saving}>Save notifications</SettingsButton>
          {msg && <span className="text-sm text-gray-600">{msg}</span>}
        </div>
      </SettingsCard>
    </div>
  );
}
