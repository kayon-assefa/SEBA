import { useEffect, useState } from "react";
import { SettingsButton, SettingsCard } from "../components";
import { integrationSettingsService } from "../services/integration-settings.service";

const PROVIDERS = ["chapa", "afripay", "google_calendar", "google_analytics", "instagram", "facebook", "tiktok"];

type Integration = { provider: string; status: string };

export default function IntegrationSectionFixed() {
  const [items, setItems] = useState<Integration[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);
  const [message, setMessage] = useState("");

  async function load() {
    const integrations = await integrationSettingsService.list();
    setItems(integrations as Integration[]);
  }

  useEffect(() => {
    let cancelled = false;

    async function loadIntegrations() {
      try {
        const integrations = await integrationSettingsService.list();
        if (!cancelled) setItems(integrations as Integration[]);
      } catch (error) {
        if (!cancelled) setMessage(error instanceof Error ? error.message : "Failed to load integrations");
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    void loadIntegrations();
    return () => {
      cancelled = true;
    };
  }, []);

  async function toggle(provider: string) {
    setBusy(provider);
    setMessage("");
    try {
      const current = items.find((item) => item.provider === provider);
      if (current?.status === "connected") await integrationSettingsService.disconnect(provider);
      else await integrationSettingsService.connect(provider);
      await load();
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Failed to update integration");
    } finally {
      setBusy(null);
    }
  }

  if (loading) return <div className="p-6 text-sm text-gray-500">Loading…</div>;

  return <div className="space-y-6"><SettingsCard title="Integrations" description="Connection state is stored in Supabase."><div className="grid gap-4 md:grid-cols-2">{PROVIDERS.map((provider) => { const integration = items.find((item) => item.provider === provider); const connected = integration?.status === "connected"; return <div key={provider} className="flex items-center justify-between rounded-xl border p-4"><div><p className="font-semibold capitalize">{provider.replaceAll("_", " ")}</p><p className="text-sm text-gray-500">{connected ? "Connected" : "Disconnected"}</p></div><SettingsButton variant={connected ? "secondary" : "primary"} loading={busy === provider} onClick={() => toggle(provider)}>{connected ? "Disconnect" : "Connect"}</SettingsButton></div>; })}</div>{message && <p className="mt-4 text-sm text-red-600">{message}</p>}</SettingsCard></div>;
}
