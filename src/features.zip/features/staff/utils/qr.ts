import { supabase } from "../../../lib/supabase";
import type { ScanResult } from "../types";

/**
 * SEBA pass QR format
 * ---------------------------------------------------------------
 * Every appointment/order gets a short unique `qr_code` (see the SQL
 * migration). A customer-facing "SEBA pass" should encode ONE of:
 *
 *   SEBA:APPT:<qr_code>     -> looked up against appointments.qr_code
 *   SEBA:ORDER:<qr_code>    -> looked up against orders.qr_code
 *
 * We also accept a bare code with no prefix (tries appointments, then
 * orders) so this keeps working even if the customer-facing app just
 * encodes the raw code. Anything that doesn't resolve to a row in THIS
 * business shows as "not found" rather than leaking other businesses' data.
 */

export type ParsedCode =
  | { kind: "appointment" | "order"; code: string }
  | { kind: "unknown"; code: string };

export function parseSebaCode(raw: string): ParsedCode {
  const text = raw.trim();
  const match = /^SEBA:(APPT|ORDER):(.+)$/i.exec(text);
  if (match) {
    const kind = match[1].toUpperCase() === "APPT" ? "appointment" : "order";
    return { kind, code: match[2].trim() };
  }
  return { kind: "unknown", code: text };
}

export async function resolveScannedCode(raw: string, businessId: string): Promise<ScanResult> {
  const parsed = parseSebaCode(raw);

  async function tryAppointment(code: string) {
    const { data } = await supabase
      .from("appointments").select("*")
      .eq("business_id", businessId).eq("qr_code", code).maybeSingle();
    return data;
  }
  async function tryOrder(code: string) {
    const { data } = await supabase
      .from("orders").select("*")
      .eq("business_id", businessId).eq("qr_code", code).maybeSingle();
    return data;
  }

  if (parsed.kind === "appointment") {
    const record = await tryAppointment(parsed.code);
    if (record) return { kind: "appointment", record };
    return { kind: "not_found", raw };
  }
  if (parsed.kind === "order") {
    const record = await tryOrder(parsed.code);
    if (record) return { kind: "order", record };
    return { kind: "not_found", raw };
  }

  // Unknown prefix / bare code — try both tables before giving up.
  const appt = await tryAppointment(parsed.code);
  if (appt) return { kind: "appointment", record: appt };
  const order = await tryOrder(parsed.code);
  if (order) return { kind: "order", record: order };
  return { kind: "not_found", raw };
}
