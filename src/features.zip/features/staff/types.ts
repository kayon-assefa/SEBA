export type Staff = {
  id: string;
  user_id: string;
  business_id: string;
  full_name: string;
  email: string;
  role: string;
  is_active: boolean;
};

export type AppointmentStatus = "pending" | "confirmed" | "completed" | "cancelled" | "no_show";

export type Appointment = {
  id: string;
  business_id: string;
  customer: string;
  customer_phone?: string | null;
  service: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:MM
  status: AppointmentStatus | string;
  notes?: string | null;
  is_recurring?: boolean | null;
  qr_code?: string | null;
  created_at?: string;
};

export type OrderStatus = "pending" | "preparing" | "ready" | "delivered" | "cancelled";
export type PaymentStatus = "unpaid" | "paid" | "partial";

export type OrderItem = { name: string; qty: number; price: number };

export type Order = {
  id: string;
  business_id: string;
  customer_name?: string | null;
  customer_phone?: string | null;
  status: OrderStatus | string;
  payment_status: PaymentStatus | string;
  items?: OrderItem[] | null;
  total_amount?: number | null;
  notes?: string | null;
  qr_code?: string | null;
  created_at: string;
};

export type Customer = {
  id: string;
  business_id: string;
  name: string;
  phone?: string | null;
  email?: string | null;
  tags?: string[] | null;
  notes?: string | null;
  created_at?: string;
};

export type StaffNotification = {
  id: string;
  business_id: string;
  staff_id: string | null; // null = broadcast to whole business
  title: string;
  body: string;
  type: "appointment" | "order" | "system" | "reminder";
  is_read: boolean;
  created_at: string;
  link?: string | null;
};

export type StaffShift = {
  id: string;
  business_id: string;
  staff_id: string;
  date: string;
  start_time: string;
  end_time: string;
  note?: string | null;
};

export type TimeOffRequest = {
  id: string;
  business_id: string;
  staff_id: string;
  start_date: string;
  end_date: string;
  reason?: string | null;
  status: "pending" | "approved" | "denied";
};

export type NotificationPrefs = {
  staff_id: string;
  email_enabled: boolean;
  sms_enabled: boolean;
  push_enabled: boolean;
};

export type ScanResult =
  | { kind: "appointment"; record: Appointment }
  | { kind: "order"; record: Order }
  | { kind: "not_found"; raw: string };
