import { supabase } from "../../../lib/supabase";
import type {
  Appointment, Order, Customer, StaffNotification, StaffShift, TimeOffRequest, NotificationPrefs,
} from "../types";

/* ------------------------------- Staff / session ------------------------------- */

export async function getCurrentStaff() {
  const { data: { user }, error: authError } = await supabase.auth.getUser();
  if (authError) throw authError;
  if (!user) throw new Error("Not authenticated.");

  const { data, error } = await supabase
    .from("business_staff")
    .select("id,user_id,business_id,full_name,email,role,is_active")
    .eq("user_id", user.id)
    .eq("is_active", true)
    .maybeSingle();

  if (error) throw error;
  if (!data) throw new Error("No active staff account found for this login.");
  return data;
}

export async function updateStaffProfile(staffId: string, patch: { full_name?: string }) {
  const { error } = await supabase.from("business_staff").update(patch).eq("id", staffId);
  if (error) throw error;
}

export async function changePassword(newPassword: string) {
  const { error } = await supabase.auth.updateUser({ password: newPassword });
  if (error) throw error;
}

/* --------------------------------- Appointments --------------------------------- */

export async function getAppointments(businessId: string): Promise<Appointment[]> {
  const { data, error } = await supabase
    .from("appointments").select("*")
    .eq("business_id", businessId)
    .order("date", { ascending: true }).order("time", { ascending: true });
  if (error) throw error;
  return data ?? [];
}

export async function updateAppointment(id: string, patch: Partial<Appointment>) {
  const { error } = await supabase.from("appointments").update(patch).eq("id", id);
  if (error) throw error;
}

export async function bulkUpdateAppointments(ids: string[], patch: Partial<Appointment>) {
  const { error } = await supabase.from("appointments").update(patch).in("id", ids);
  if (error) throw error;
}

/** Returns true if moving `appointmentId` to date/time would collide with another appointment. */
export function hasConflict(appointments: Appointment[], appointmentId: string, date: string, time: string) {
  return appointments.some(a => a.id !== appointmentId && a.date === date && a.time === time);
}

/* ------------------------------------ Orders ------------------------------------ */

export async function getOrders(businessId: string): Promise<Order[]> {
  const { data, error } = await supabase
    .from("orders").select("*")
    .eq("business_id", businessId)
    .order("created_at", { ascending: false });
  if (error) throw error;
  return data ?? [];
}

export async function updateOrder(id: string, patch: Partial<Order>) {
  const { error } = await supabase.from("orders").update(patch).eq("id", id);
  if (error) throw error;
}

/* ----------------------------------- Customers ----------------------------------- */

export async function getCustomers(businessId: string): Promise<Customer[]> {
  const { data, error } = await supabase
    .from("customers").select("*")
    .eq("business_id", businessId)
    .order("created_at", { ascending: false });
  if (error) throw error;
  return data ?? [];
}

export async function updateCustomer(id: string, patch: Partial<Customer>) {
  const { error } = await supabase.from("customers").update(patch).eq("id", id);
  if (error) throw error;
}

/* --------------------------------- Notifications --------------------------------- */

export async function getNotifications(businessId: string, staffId: string): Promise<StaffNotification[]> {
  const { data, error } = await supabase
    .from("staff_notifications").select("*")
    .eq("business_id", businessId)
    .or(`staff_id.eq.${staffId},staff_id.is.null`)
    .order("created_at", { ascending: false })
    .limit(50);
  if (error) throw error;
  return data ?? [];
}

export async function markNotificationRead(id: string) {
  const { error } = await supabase.from("staff_notifications").update({ is_read: true }).eq("id", id);
  if (error) throw error;
}

export async function markAllNotificationsRead(businessId: string, staffId: string) {
  const { error } = await supabase
    .from("staff_notifications").update({ is_read: true })
    .eq("business_id", businessId)
    .or(`staff_id.eq.${staffId},staff_id.is.null`)
    .eq("is_read", false);
  if (error) throw error;
}

export async function getNotificationPrefs(staffId: string): Promise<NotificationPrefs | null> {
  const { data, error } = await supabase
    .from("staff_notification_prefs").select("*").eq("staff_id", staffId).maybeSingle();
  if (error) throw error;
  return data;
}

export async function saveNotificationPrefs(staffId: string, businessId: string, prefs: Partial<NotificationPrefs>) {
  const { error } = await supabase
    .from("staff_notification_prefs")
    .upsert({ staff_id: staffId, business_id: businessId, ...prefs }, { onConflict: "staff_id" });
  if (error) throw error;
}

/** Store a browser push subscription so a server-side job can send real push notifications later. */
export async function savePushSubscription(staffId: string, businessId: string, subscription: PushSubscriptionJSON) {
  const { error } = await supabase.from("push_subscriptions").upsert({
    staff_id: staffId,
    business_id: businessId,
    endpoint: subscription.endpoint,
    subscription,
  }, { onConflict: "endpoint" });
  if (error) throw error;
}

/* ----------------------------------- Schedule ----------------------------------- */

export async function getShifts(businessId: string): Promise<StaffShift[]> {
  const { data, error } = await supabase
    .from("staff_shifts").select("*")
    .eq("business_id", businessId)
    .order("date", { ascending: true });
  if (error) throw error;
  return data ?? [];
}

export async function getTimeOffRequests(businessId: string, staffId: string): Promise<TimeOffRequest[]> {
  const { data, error } = await supabase
    .from("staff_time_off").select("*")
    .eq("business_id", businessId).eq("staff_id", staffId)
    .order("start_date", { ascending: false });
  if (error) throw error;
  return data ?? [];
}

export async function requestTimeOff(businessId: string, staffId: string, req: { start_date: string; end_date: string; reason?: string }) {
  const { error } = await supabase.from("staff_time_off").insert({
    business_id: businessId, staff_id: staffId, status: "pending", ...req,
  });
  if (error) throw error;
}
