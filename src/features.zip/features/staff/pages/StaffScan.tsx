import { useState } from "react";
import { useStaff } from "../context/StaffContext";
import { QRScanner } from "../components/QRScanner";
import { resolveScannedCode } from "../utils/qr";
import { Icon } from "../components/Icons";
import { StatusPill } from "../components/UIKit";
import { formatDate, formatTime, formatDateTime, formatCurrency } from "../utils/format";
import type { ScanResult } from "../types";

export default function StaffScan() {
  const { staff } = useStaff();
  const [result, setResult] = useState<ScanResult | null>(null);
  const [checking, setChecking] = useState(false);

  async function handleDetect(raw: string) {
    if (!staff || checking) return;
    setChecking(true);
    try {
      const r = await resolveScannedCode(raw, staff.business_id);
      setResult(r);
    } finally {
      setChecking(false);
    }
  }

  return (
    <div style={{ maxWidth: 480, margin: "0 auto" }}>
      <div style={{ textAlign: "center", marginBottom: 22 }}>
        <h1 className="ss-h1">Scan a SEBA pass</h1>
        <p className="ss-sub">Point the camera at a customer's appointment or order pass.</p>
      </div>

      {!result && <QRScanner onDetect={handleDetect} />}

      {checking && (
        <div style={{ textAlign: "center", marginTop: 20, color: "var(--text-muted)", fontSize: 13.5 }}>
          Looking up code…
        </div>
      )}

      {result && !checking && <ScanResultView result={result} onRescan={() => setResult(null)} />}
    </div>
  );
}

function ScanResultView({ result, onRescan }: { result: ScanResult; onRescan: () => void }) {
  if (result.kind === "not_found") {
    return (
      <div className="ss-card ss-card-pad" style={{ textAlign: "center", marginTop: 20 }}>
        <div style={{
          width: 64, height: 64, borderRadius: "50%", background: "var(--danger-bg)", color: "var(--danger)",
          display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 14px",
        }}>
          <Icon.XCircle size={30} />
        </div>
        <h2 className="ss-h2" style={{ marginBottom: 6 }}>Scanned, but not found</h2>
        <p className="ss-sub" style={{ marginBottom: 18 }}>
          That code isn't a valid SEBA pass for this business. It may belong to a different business, or the pass may be expired.
        </p>
        <button className="ss-btn ss-btn-primary" onClick={onRescan}>Scan again</button>
      </div>
    );
  }

  if (result.kind === "appointment") {
    const a = result.record;
    return (
      <div className="ss-card ss-card-pad" style={{ marginTop: 20 }}>
        <ResultHeader label="Appointment found" />
        <h2 className="ss-h2" style={{ marginTop: 10 }}>{a.customer}</h2>
        <p className="ss-sub">{a.service}</p>
        <div style={{ display: "flex", gap: 10, marginTop: 10, alignItems: "center" }}>
          <StatusPill status={a.status} />
          <span style={{ fontSize: 13, color: "var(--text-muted)" }}>{formatDate(a.date)} · {formatTime(a.time)}</span>
        </div>
        {a.notes && <p style={{ marginTop: 12, fontSize: 13, color: "var(--text-muted)" }}><b>Notes:</b> {a.notes}</p>}
        <button className="ss-btn ss-btn-secondary" style={{ marginTop: 18 }} onClick={onRescan}>Scan another</button>
      </div>
    );
  }

  const o = result.record;
  return (
    <div className="ss-card ss-card-pad" style={{ marginTop: 20 }}>
      <ResultHeader label="Order found" />
      <h2 className="ss-h2" style={{ marginTop: 10 }}>{o.customer_name || "Customer"}</h2>
      <div style={{ display: "flex", gap: 10, marginTop: 10, alignItems: "center" }}>
        <StatusPill status={o.status} /><StatusPill status={o.payment_status} />
      </div>
      <p style={{ marginTop: 10, fontSize: 13, color: "var(--text-muted)" }}>
        Placed {formatDateTime(o.created_at)} {o.total_amount != null ? `· ${formatCurrency(o.total_amount)}` : ""}
      </p>
      <button className="ss-btn ss-btn-secondary" style={{ marginTop: 18 }} onClick={onRescan}>Scan another</button>
    </div>
  );
}

function ResultHeader({ label }: { label: string }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8, color: "var(--success)", fontWeight: 700, fontSize: 13 }}>
      <Icon.CheckCircle size={17} /> {label}
    </div>
  );
}
