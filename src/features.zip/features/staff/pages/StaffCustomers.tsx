import React, { useEffect, useMemo, useState } from "react";
import { useStaff } from "../context/StaffContext";
import { useToast } from "../context/ToastContext";
import { getCustomers, updateCustomer, getAppointments } from "../services/staffData";
import { useRealtime } from "../hooks/useRealtime";
import { Avatar, EmptyState, SkeletonRows } from "../components/UIKit";
import { Modal } from "../components/Modal";
import { Icon } from "../components/Icons";
import { formatDate } from "../utils/format";
import type { Customer, Appointment } from "../types";

export default function StaffCustomers() {
  const { staff } = useStaff();
  const toast = useToast();
  const [rows, setRows] = useState<Customer[]>([]);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [active, setActive] = useState<Customer | null>(null);

  async function load() {
    if (!staff) return;
    try {
      const [c, a] = await Promise.all([getCustomers(staff.business_id), getAppointments(staff.business_id)]);
      setRows(c); setAppointments(a);
    } catch (e: any) { toast.show(e.message || "Couldn't load customers.", "error"); }
    finally { setLoading(false); }
  }
  useEffect(() => { load(); }, [staff?.id]); // eslint-disable-line
  useRealtime(["customers"], staff?.business_id, load);

  const filtered = useMemo(() => {
    if (!search.trim()) return rows;
    const s = search.toLowerCase();
    return rows.filter(c => c.name?.toLowerCase().includes(s) || c.phone?.includes(s) || c.email?.toLowerCase().includes(s));
  }, [rows, search]);

  function visitsFor(c: Customer) {
    return appointments.filter(a => a.customer?.toLowerCase() === c.name?.toLowerCase() || (c.phone && a.customer_phone === c.phone));
  }

  return (
    <div>
      <div className="ss-row-between" style={{ marginBottom: 18 }}>
        <div><h1 className="ss-h1">Customers</h1><p className="ss-sub">{filtered.length} shown</p></div>
        <input className="ss-input" placeholder="Search name, phone, email…" style={{ maxWidth: 260 }} value={search} onChange={e => setSearch(e.target.value)} />
      </div>

      {loading ? <SkeletonRows rows={5} /> : filtered.length === 0 ? (
        <div className="ss-card ss-card-pad"><EmptyState title="No customers match" icon={<Icon.Users size={36} />} /></div>
      ) : (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: 14 }}>
          {filtered.map(c => {
            const visits = visitsFor(c);
            return (
              <div key={c.id} className="ss-card ss-card-pad" style={{ cursor: "pointer" }} onClick={() => setActive(c)}>
                <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
                  <Avatar name={c.name} size="lg" />
                  <div style={{ minWidth: 0 }}>
                    <div style={{ fontWeight: 800, fontSize: 15 }}>{c.name}</div>
                    <div style={{ fontSize: 12.5, color: "var(--text-muted)" }}>{c.phone || c.email || "No contact info"}</div>
                  </div>
                </div>
                {c.tags?.length ? (
                  <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 12 }}>
                    {c.tags.map(t => <span key={t} className="ss-chip active" style={{ cursor: "default" }}>{t}</span>)}
                  </div>
                ) : null}
                <div style={{ marginTop: 12, fontSize: 12, color: "var(--text-faint)" }}>
                  {visits.length} visit{visits.length === 1 ? "" : "s"}{visits.length > 1 ? " · repeat customer" : ""}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {active && (
        <CustomerModal
          customer={active} visits={visitsFor(active)}
          onClose={() => setActive(null)}
          onSaved={() => { setActive(null); load(); }}
        />
      )}
    </div>
  );
}

function CustomerModal({
  customer, visits, onClose, onSaved,
}: { customer: Customer; visits: Appointment[]; onClose: () => void; onSaved: () => void }) {
  const toast = useToast();
  const [notes, setNotes] = useState(customer.notes || "");
  const [tagsInput, setTagsInput] = useState((customer.tags || []).join(", "));
  const [saving, setSaving] = useState(false);

  async function save() {
    setSaving(true);
    try {
      const tags = tagsInput.split(",").map(t => t.trim()).filter(Boolean);
      await updateCustomer(customer.id, { notes, tags });
      toast.show("Customer updated.", "success");
      onSaved();
    } catch (e: any) { toast.show(e.message || "Couldn't save — has the `tags`/`notes` migration been run?", "error"); }
    finally { setSaving(false); }
  }

  return (
    <Modal
      title={customer.name} onClose={onClose}
      footer={<>
        <button className="ss-btn ss-btn-secondary" onClick={onClose}>Close</button>
        <button className="ss-btn ss-btn-primary" disabled={saving} onClick={save}>{saving ? "Saving…" : "Save"}</button>
      </>}
    >
      <div style={{ display: "flex", gap: 16, fontSize: 13, color: "var(--text-muted)", marginBottom: 16 }}>
        {customer.phone && <span><Icon.Phone size={13} /> {customer.phone}</span>}
        {customer.email && <span><Icon.Mail size={13} /> {customer.email}</span>}
      </div>

      <div className="ss-field"><label>Tags (comma-separated — e.g. VIP, allergic to nuts)</label>
        <input className="ss-input" value={tagsInput} onChange={e => setTagsInput(e.target.value)} placeholder="VIP, prefers evenings" />
      </div>
      <div className="ss-field"><label>Notes</label>
        <textarea className="ss-textarea" rows={3} value={notes} onChange={e => setNotes(e.target.value)} placeholder="Anything staff should know before their next visit…" />
      </div>

      <hr className="ss-divider" />
      <div className="ss-eyebrow" style={{ marginBottom: 8 }}>Visit history ({visits.length})</div>
      {visits.length === 0 ? (
        <p style={{ fontSize: 12.5, color: "var(--text-faint)" }}>No matched appointments yet.</p>
      ) : (
        <div style={{ maxHeight: 180, overflowY: "auto" }} className="scrollbar">
          {visits.map(v => (
            <div key={v.id} style={{ display: "flex", justifyContent: "space-between", fontSize: 12.5, padding: "6px 0", borderBottom: "1px solid var(--border)" }}>
              <span>{v.service}</span><span style={{ color: "var(--text-muted)" }}>{formatDate(v.date)}</span>
            </div>
          ))}
        </div>
      )}
    </Modal>
  );
}
