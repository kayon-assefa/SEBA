import React, { useEffect, useMemo, useState } from "react";
import { useStaff } from "../context/StaffContext";
import { useToast } from "../context/ToastContext";
import { getOrders, updateOrder } from "../services/staffData";
import { useRealtime } from "../hooks/useRealtime";
import { DataTable } from "../components/DataTable";
import type { Column } from "../components/DataTable";
import { StatusPill, FilterChips } from "../components/UIKit";
import { Modal } from "../components/Modal";
import { formatDateTime, formatCurrency } from "../utils/format";
import type { Order } from "../types";

const STATUS_OPTIONS = [
  { value: "pending", label: "Pending" }, { value: "preparing", label: "Preparing" },
  { value: "ready", label: "Ready" }, { value: "delivered", label: "Delivered" }, { value: "cancelled", label: "Cancelled" },
];

export default function StaffOrders() {
  const { staff } = useStaff();
  const toast = useToast();
  const [rows, setRows] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState<string[]>([]);
  const [search, setSearch] = useState("");
  const [detail, setDetail] = useState<Order | null>(null);

  async function load() {
    if (!staff) return;
    try { setRows(await getOrders(staff.business_id)); }
    catch (e: any) { toast.show(e.message || "Couldn't load orders.", "error"); }
    finally { setLoading(false); }
  }
  useEffect(() => { load(); }, [staff?.id]); // eslint-disable-line
  useRealtime(["orders"], staff?.business_id, load);

  const filtered = useMemo(() => {
    let r = rows;
    if (statusFilter.length) r = r.filter(o => statusFilter.includes(String(o.status).toLowerCase()));
    if (search.trim()) {
      const s = search.toLowerCase();
      r = r.filter(o => o.customer_name?.toLowerCase().includes(s) || o.customer_phone?.includes(s));
    }
    return r;
  }, [rows, statusFilter, search]);

  const columns: Column<Order>[] = [
    { key: "customer", header: "Customer", sortValue: o => o.customer_name || "", render: o => <b>{o.customer_name || "Customer"}</b> },
    { key: "phone", header: "Phone", render: o => o.customer_phone || "—" },
    { key: "total", header: "Total", sortValue: o => o.total_amount || 0, render: o => formatCurrency(o.total_amount) },
    { key: "status", header: "Status", sortValue: o => o.status || "", render: o => <StatusPill status={o.status} /> },
    { key: "payment", header: "Payment", sortValue: o => o.payment_status || "", render: o => <StatusPill status={o.payment_status} /> },
    { key: "created", header: "Placed", sortValue: o => o.created_at, render: o => formatDateTime(o.created_at) },
  ];

  return (
    <div>
      <div className="ss-row-between" style={{ marginBottom: 18 }}>
        <div><h1 className="ss-h1">Orders</h1><p className="ss-sub">{filtered.length} shown</p></div>
        <input className="ss-input" placeholder="Search customer or phone…" style={{ maxWidth: 240 }} value={search} onChange={e => setSearch(e.target.value)} />
      </div>

      <div style={{ marginBottom: 16 }}>
        <FilterChips value={statusFilter} onChange={setStatusFilter} options={STATUS_OPTIONS} />
      </div>

      <DataTable columns={columns} rows={filtered} loading={loading} onRowClick={(row: Order) => setDetail(row)} pageSize={9}
        emptyTitle="No orders match" emptySubtitle="Try clearing filters." />

      {detail && (
        <OrderDetailModal order={detail} onClose={() => setDetail(null)} onSaved={() => { setDetail(null); load(); }} />
      )}
    </div>
  );
}

function OrderDetailModal({ order, onClose, onSaved }: { order: Order; onClose: () => void; onSaved: () => void }) {
  const toast = useToast();
  const [status, setStatus] = useState(order.status);
  const [payment, setPayment] = useState(order.payment_status);
  const [saving, setSaving] = useState(false);

  async function save() {
    setSaving(true);
    try {
      await updateOrder(order.id, { status, payment_status: payment });
      toast.show("Order updated.", "success");
      onSaved();
    } catch (e: any) { toast.show(e.message || "Couldn't update order.", "error"); }
    finally { setSaving(false); }
  }

  return (
    <Modal
      title={`Order — ${order.customer_name || "Customer"}`} onClose={onClose}
      footer={<>
        <button className="ss-btn ss-btn-secondary" onClick={onClose}>Close</button>
        <button className="ss-btn ss-btn-primary" disabled={saving} onClick={save}>{saving ? "Saving…" : "Save changes"}</button>
      </>}
    >
      <div style={{ fontSize: 13, color: "var(--text-muted)", marginBottom: 14 }}>
        Placed {formatDateTime(order.created_at)} {order.customer_phone ? `· ${order.customer_phone}` : ""}
      </div>

      {order.items?.length ? (
        <div style={{ marginBottom: 16 }}>
          {order.items.map((it, i) => (
            <div key={i} style={{ display: "flex", justifyContent: "space-between", fontSize: 13.5, padding: "6px 0", borderBottom: "1px solid var(--border)" }}>
              <span>{it.qty}× {it.name}</span><span>{formatCurrency(it.price * it.qty)}</span>
            </div>
          ))}
          <div style={{ display: "flex", justifyContent: "space-between", fontWeight: 800, paddingTop: 8 }}>
            <span>Total</span><span>{formatCurrency(order.total_amount)}</span>
          </div>
        </div>
      ) : (
        <p style={{ fontSize: 12.5, color: "var(--text-faint)", marginBottom: 16 }}>
          No itemized line items on this order yet.
        </p>
      )}

      <div style={{ display: "flex", gap: 12 }}>
        <div className="ss-field" style={{ flex: 1 }}><label>Order status</label>
          <select className="ss-select" value={status} onChange={e => setStatus(e.target.value)}>
            {STATUS_OPTIONS.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
          </select>
        </div>
        <div className="ss-field" style={{ flex: 1 }}><label>Payment status</label>
          <select className="ss-select" value={payment} onChange={e => setPayment(e.target.value)}>
            {["unpaid", "paid", "partial"].map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
      </div>

      {order.notes && (
        <div style={{ marginTop: 4, fontSize: 13, color: "var(--text-muted)" }}><b>Notes:</b> {order.notes}</div>
      )}
    </Modal>
  );
}
