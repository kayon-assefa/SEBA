import React, { useEffect, useMemo, useState } from "react";
import { useStaff } from "../context/StaffContext";
import { useToast } from "../context/ToastContext";
import { getAppointments, updateAppointment, bulkUpdateAppointments, hasConflict } from "../services/staffData";
import { useRealtime } from "../hooks/useRealtime";
import { DataTable } from "../components/DataTable";
import type { Column } from "../components/DataTable";
import { StatusPill, Tabs, FilterChips } from "../components/UIKit";
import { Modal, ConfirmDialog } from "../components/Modal";
import { Icon } from "../components/Icons";
import { formatDate, formatTime, todayISO } from "../utils/format";
import type { Appointment } from "../types";

const STATUS_OPTIONS: { value: string; label: string }[] = [
  { value: "pending", label: "Pending" },
  { value: "confirmed", label: "Confirmed" },
  { value: "completed", label: "Completed" },
  { value: "cancelled", label: "Cancelled" },
  { value: "no_show", label: "No-show" },
];

export default function StaffAppointments() {
  const { staff } = useStaff();
  const toast = useToast();
  const [rows, setRows] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState<"list" | "calendar">("list");
  const [tab, setTab] = useState<"all" | "today" | "upcoming" | "past">("today");
  const [statusFilter, setStatusFilter] = useState<string[]>([]);
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [reschedule, setReschedule] = useState<Appointment | null>(null);
  const [confirmCancel, setConfirmCancel] = useState<Appointment | null>(null);
  const [dragOverDay, setDragOverDay] = useState<string | null>(null);

  async function load() {
    if (!staff) return;
    try { setRows(await getAppointments(staff.business_id)); }
    catch (e: any) { toast.show(e.message || "Couldn't load appointments.", "error"); }
    finally { setLoading(false); }
  }
  useEffect(() => { load(); }, [staff?.id]); // eslint-disable-line
  useRealtime(["appointments"], staff?.business_id, load);

  const today = todayISO();
  const filtered = useMemo(() => {
    let r = rows;
    if (tab === "today") r = r.filter(a => a.date === today);
    if (tab === "upcoming") r = r.filter(a => a.date > today);
    if (tab === "past") r = r.filter(a => a.date < today);
    if (statusFilter.length) r = r.filter(a => statusFilter.includes(String(a.status).toLowerCase()));
    if (search.trim()) {
      const s = search.toLowerCase();
      r = r.filter(a => a.customer?.toLowerCase().includes(s) || a.service?.toLowerCase().includes(s));
    }
    return r;
  }, [rows, tab, statusFilter, search, today]);

  async function setStatus(a: Appointment, status: string) {
    try {
      await updateAppointment(a.id, { status });
      toast.show(`Marked as ${status.replace("_", " ")}.`, "success");
      load();
    } catch (e: any) { toast.show(e.message || "Update failed.", "error"); }
  }

  async function bulkSetStatus(status: string) {
    if (!selected.size) return;
    try {
      await bulkUpdateAppointments([...selected], { status });
      toast.show(`${selected.size} appointments updated.`, "success");
      setSelected(new Set());
      load();
    } catch (e: any) { toast.show(e.message || "Bulk update failed.", "error"); }
  }

  const columns: Column<Appointment>[] = [
    {
      key: "select", header: "", width: "34px",
      render: a => (
        <input type="checkbox" checked={selected.has(a.id)} onClick={e => e.stopPropagation()}
          onChange={e => {
            const next = new Set(selected);
            e.target.checked ? next.add(a.id) : next.delete(a.id);
            setSelected(next);
          }} />
      ),
    },
    { key: "customer", header: "Customer", sortValue: a => a.customer || "", render: a => <b>{a.customer}</b> },
    { key: "service", header: "Service", sortValue: a => a.service || "", render: a => a.service },
    { key: "when", header: "When", sortValue: a => `${a.date}${a.time}`, render: a => <>{formatDate(a.date)} · {formatTime(a.time)}</> },
    { key: "status", header: "Status", sortValue: a => a.status || "", render: a => <StatusPill status={a.status} /> },
    {
      key: "actions", header: "", render: a => (
        <div style={{ display: "flex", gap: 6 }} onClick={e => e.stopPropagation()}>
          {a.status !== "confirmed" && a.status !== "completed" && (
            <button className="ss-btn ss-btn-secondary ss-btn-sm" onClick={() => setStatus(a, "confirmed")}>Confirm</button>
          )}
          {a.status !== "completed" && (
            <button className="ss-btn ss-btn-secondary ss-btn-sm" onClick={() => setStatus(a, "completed")}>Complete</button>
          )}
          <button className="ss-btn ss-btn-secondary ss-btn-sm" onClick={() => setReschedule(a)}>Reschedule</button>
          <button className="ss-btn ss-btn-danger ss-btn-sm" onClick={() => setConfirmCancel(a)}>Cancel</button>
        </div>
      ),
    },
  ];

  return (
    <div>
      <div className="ss-row-between" style={{ marginBottom: 18 }}>
        <div>
          <h1 className="ss-h1">Appointments</h1>
          <p className="ss-sub">{filtered.length} shown</p>
        </div>
        <div className="ss-tabs">
          <button className={`ss-tab ${view === "list" ? "active" : ""}`} onClick={() => setView("list")}>List</button>
          <button className={`ss-tab ${view === "calendar" ? "active" : ""}`} onClick={() => setView("calendar")}>Week</button>
        </div>
      </div>

      <div className="ss-row-between" style={{ marginBottom: 16 }}>
        <Tabs
          value={tab} onChange={(v: typeof tab) => setTab(v)}
          options={[
            { value: "today", label: "Today" }, { value: "upcoming", label: "Upcoming" },
            { value: "past", label: "Past" }, { value: "all", label: "All" },
          ] as const}
        />
        <input className="ss-input" placeholder="Search customer or service…" style={{ maxWidth: 240 }} value={search} onChange={e => setSearch(e.target.value)} />
      </div>

      <div style={{ marginBottom: 16 }}>
        <FilterChips value={statusFilter} onChange={setStatusFilter} options={STATUS_OPTIONS} />
      </div>

      {selected.size > 0 && (
        <div className="ss-card ss-card-pad" style={{ marginBottom: 14, display: "flex", alignItems: "center", gap: 10 }}>
          <span style={{ fontSize: 13, fontWeight: 700 }}>{selected.size} selected</span>
          <button className="ss-btn ss-btn-secondary ss-btn-sm" onClick={() => bulkSetStatus("confirmed")}>Confirm all</button>
          <button className="ss-btn ss-btn-secondary ss-btn-sm" onClick={() => bulkSetStatus("completed")}>Complete all</button>
          <button className="ss-btn ss-btn-danger ss-btn-sm" onClick={() => bulkSetStatus("cancelled")}>Cancel all</button>
          <button className="ss-btn ss-btn-ghost ss-btn-sm" style={{ marginLeft: "auto" }} onClick={() => setSelected(new Set())}>Clear</button>
        </div>
      )}

      {view === "list" ? (
        <DataTable
          columns={columns} rows={filtered} loading={loading}
          emptyTitle="No appointments match" emptySubtitle="Try clearing filters."
          pageSize={9}
        />
      ) : (
        <WeekCalendar
          rows={rows} onDropAppointment={async (a, newDate) => {
            if (hasConflict(rows, a.id, newDate, a.time)) {
              toast.show(`${a.customer} already has something at ${formatTime(a.time)} that day — pick another time.`, "error");
              return;
            }
            await updateAppointment(a.id, { date: newDate });
            toast.show("Rescheduled.", "success");
            load();
          }}
          dragOverDay={dragOverDay} setDragOverDay={setDragOverDay}
          onOpen={setReschedule}
        />
      )}

      {reschedule && (
        <RescheduleModal
          appointment={reschedule} allAppointments={rows}
          onClose={() => setReschedule(null)}
          onSaved={() => { setReschedule(null); load(); }}
        />
      )}

      {confirmCancel && (
        <ConfirmDialog
          title="Cancel appointment?"
          message={`This marks ${confirmCancel.customer}'s appointment as cancelled. This can't be undone from here.`}
          confirmLabel="Cancel appointment" danger
          onCancel={() => setConfirmCancel(null)}
          onConfirm={async () => { await setStatus(confirmCancel, "cancelled"); setConfirmCancel(null); }}
        />
      )}
    </div>
  );
}

function RescheduleModal({
  appointment, allAppointments, onClose, onSaved,
}: { appointment: Appointment; allAppointments: Appointment[]; onClose: () => void; onSaved: () => void }) {
  const toast = useToast();
  const [date, setDate] = useState(appointment.date);
  const [time, setTime] = useState(appointment.time);
  const [saving, setSaving] = useState(false);
  const conflict = hasConflict(allAppointments, appointment.id, date, time);

  async function save() {
    setSaving(true);
    try {
      await updateAppointment(appointment.id, { date, time });
      toast.show("Appointment rescheduled.", "success");
      onSaved();
    } catch (e: any) { toast.show(e.message || "Couldn't reschedule.", "error"); }
    finally { setSaving(false); }
  }

  return (
    <Modal
      title={`Reschedule — ${appointment.customer}`} onClose={onClose}
      footer={<>
        <button className="ss-btn ss-btn-secondary" onClick={onClose}>Cancel</button>
        <button className="ss-btn ss-btn-primary" disabled={saving || conflict} onClick={save}>{saving ? "Saving…" : "Save new time"}</button>
      </>}
    >
      <div style={{ display: "flex", gap: 12 }}>
        <div className="ss-field" style={{ flex: 1 }}><label>Date</label>
          <input type="date" className="ss-input" value={date} onChange={e => setDate(e.target.value)} />
        </div>
        <div className="ss-field" style={{ flex: 1 }}><label>Time</label>
          <input type="time" className="ss-input" value={time} onChange={e => setTime(e.target.value)} />
        </div>
      </div>
      {conflict && (
        <div style={{ display: "flex", gap: 8, alignItems: "flex-start", padding: 12, background: "var(--danger-bg)", borderRadius: "var(--radius-sm)", color: "var(--danger)", fontSize: 13 }}>
          <Icon.AlertTriangle size={16} /> This slot is already taken. Pick a different time.
        </div>
      )}
    </Modal>
  );
}

function WeekCalendar({
  rows, onDropAppointment, dragOverDay, setDragOverDay, onOpen,
}: {
  rows: Appointment[];
  onDropAppointment: (a: Appointment, newDate: string) => void;
  dragOverDay: string | null;
  setDragOverDay: (d: string | null) => void;
  onOpen: (a: Appointment) => void;
}) {
  const days = useMemo(() => {
    const start = new Date();
    start.setDate(start.getDate() - start.getDay());
    return Array.from({ length: 7 }).map((_, i) => {
      const d = new Date(start); d.setDate(start.getDate() + i);
      return d.toISOString().slice(0, 10);
    });
  }, []);

  return (
    <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 10, overflowX: "auto" }}>
      {days.map(day => {
        const dayRows = rows.filter(a => a.date === day).sort((a, b) => a.time.localeCompare(b.time));
        return (
          <div
            key={day}
            className={`ss-card ss-card-pad ${dragOverDay === day ? "ss-drag-over" : ""}`}
            style={{ minHeight: 220, minWidth: 140 }}
            onDragOver={e => { e.preventDefault(); setDragOverDay(day); }}
            onDragLeave={() => setDragOverDay(null)}
            onDrop={e => {
              e.preventDefault();
              const id = e.dataTransfer.getData("text/appointment-id");
              const a = rows.find(x => x.id === id);
              setDragOverDay(null);
              if (a) onDropAppointment(a, day);
            }}
          >
            <div className="ss-eyebrow" style={{ marginBottom: 8 }}>{formatDate(day)}</div>
            <div style={{ display: "grid", gap: 6 }}>
              {dayRows.map(a => (
                <div
                  key={a.id} draggable
                  onDragStart={e => e.dataTransfer.setData("text/appointment-id", a.id)}
                  onClick={() => onOpen(a)}
                  style={{
                    padding: "8px 10px", borderRadius: 10, background: "var(--surface-2)",
                    border: "1px solid var(--border)", cursor: "grab", fontSize: 12,
                  }}
                >
                  <div style={{ fontWeight: 700 }}>{formatTime(a.time)}</div>
                  <div style={{ color: "var(--text-muted)" }}>{a.customer}</div>
                </div>
              ))}
              {!dayRows.length && <div style={{ fontSize: 11.5, color: "var(--text-faint)" }}>Nothing scheduled</div>}
            </div>
          </div>
        );
      })}
    </div>
  );
}
