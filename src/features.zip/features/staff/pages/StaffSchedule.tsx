import React, { useEffect, useState } from "react";
import { useStaff } from "../context/StaffContext";
import { useToast } from "../context/ToastContext";
import { getAppointments, getShifts, getTimeOffRequests, requestTimeOff } from "../services/staffData";
import { EmptyState, SkeletonRows, StatusPill } from "../components/UIKit";
import { Modal } from "../components/Modal";
import { Icon } from "../components/Icons";
import { formatDate, formatTime, todayISO } from "../utils/format";
import type { Appointment, StaffShift, TimeOffRequest } from "../types";

export default function StaffSchedule() {
  const { staff } = useStaff();
  const toast = useToast();
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [shifts, setShifts] = useState<StaffShift[]>([]);
  const [timeOff, setTimeOff] = useState<TimeOffRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [requestOpen, setRequestOpen] = useState(false);

  async function load() {
    if (!staff) return;
    try {
      const [a, s, t] = await Promise.all([
        getAppointments(staff.business_id),
        getShifts(staff.business_id).catch(() => []),
        getTimeOffRequests(staff.business_id, staff.id).catch(() => []),
      ]);
      setAppointments(a); setShifts(s); setTimeOff(t);
    } catch (e: any) { toast.show(e.message || "Couldn't load your schedule.", "error"); }
    finally { setLoading(false); }
  }
  useEffect(() => { load(); }, [staff?.id]); // eslint-disable-line

  const myShifts = shifts.filter(s => s.staff_id === staff?.id && s.date >= todayISO());

  if (loading) return <SkeletonRows rows={5} />;

  return (
    <div>
      <div className="ss-row-between" style={{ marginBottom: 18 }}>
        <div><h1 className="ss-h1">Schedule</h1><p className="ss-sub">Your shifts and time off.</p></div>
        <button className="ss-btn ss-btn-primary" onClick={() => setRequestOpen(true)}><Icon.Plus size={14} /> Request time off</button>
      </div>

      <section className="ss-card ss-card-pad" style={{ marginBottom: 16 }}>
        <h2 className="ss-h2" style={{ marginBottom: 12 }}>Your upcoming shifts</h2>
        {myShifts.length === 0 ? (
          <EmptyState title="No shifts scheduled" subtitle="Ask your manager to add you to the roster." icon={<Icon.Clock size={32} />} />
        ) : myShifts.map(s => (
          <div key={s.id} style={{ display: "flex", justifyContent: "space-between", padding: "10px 0", borderBottom: "1px solid var(--border)" }}>
            <b>{formatDate(s.date)}</b>
            <span style={{ color: "var(--text-muted)" }}>{formatTime(s.start_time)} – {formatTime(s.end_time)}</span>
          </div>
        ))}
      </section>

      <section className="ss-card ss-card-pad" style={{ marginBottom: 16 }}>
        <h2 className="ss-h2" style={{ marginBottom: 12 }}>Appointment schedule</h2>
        {appointments.length === 0 ? <EmptyState title="Nothing on the books" /> : appointments.slice(0, 20).map(a => (
          <div key={a.id} style={{ display: "flex", justifyContent: "space-between", padding: "10px 0", borderBottom: "1px solid var(--border)" }}>
            <span>{formatDate(a.date)} · {formatTime(a.time)} — <b>{a.customer}</b> — {a.service}</span>
            <StatusPill status={a.status} />
          </div>
        ))}
      </section>

      <section className="ss-card ss-card-pad">
        <h2 className="ss-h2" style={{ marginBottom: 12 }}>Your time-off requests</h2>
        {timeOff.length === 0 ? <EmptyState title="No requests yet" /> : timeOff.map(t => (
          <div key={t.id} style={{ display: "flex", justifyContent: "space-between", padding: "10px 0", borderBottom: "1px solid var(--border)" }}>
            <span>{formatDate(t.start_date)} → {formatDate(t.end_date)} {t.reason ? `· ${t.reason}` : ""}</span>
            <StatusPill status={t.status} />
          </div>
        ))}
      </section>

      {requestOpen && staff && (
        <TimeOffModal businessId={staff.business_id} staffId={staff.id} onClose={() => setRequestOpen(false)} onSaved={() => { setRequestOpen(false); load(); }} />
      )}
    </div>
  );
}

function TimeOffModal({
  businessId, staffId, onClose, onSaved,
}: { businessId: string; staffId: string; onClose: () => void; onSaved: () => void }) {
  const toast = useToast();
  const [startDate, setStartDate] = useState(todayISO());
  const [endDate, setEndDate] = useState(todayISO());
  const [reason, setReason] = useState("");
  const [saving, setSaving] = useState(false);

  async function save() {
    setSaving(true);
    try {
      await requestTimeOff(businessId, staffId, { start_date: startDate, end_date: endDate, reason });
      toast.show("Time-off request submitted.", "success");
      onSaved();
    } catch (e: any) { toast.show(e.message || "Couldn't submit — has the time-off migration been run?", "error"); }
    finally { setSaving(false); }
  }

  return (
    <Modal
      title="Request time off" onClose={onClose}
      footer={<>
        <button className="ss-btn ss-btn-secondary" onClick={onClose}>Cancel</button>
        <button className="ss-btn ss-btn-primary" disabled={saving} onClick={save}>{saving ? "Submitting…" : "Submit request"}</button>
      </>}
    >
      <div style={{ display: "flex", gap: 12 }}>
        <div className="ss-field" style={{ flex: 1 }}><label>From</label>
          <input type="date" className="ss-input" value={startDate} onChange={e => setStartDate(e.target.value)} />
        </div>
        <div className="ss-field" style={{ flex: 1 }}><label>To</label>
          <input type="date" className="ss-input" value={endDate} onChange={e => setEndDate(e.target.value)} />
        </div>
      </div>
      <div className="ss-field"><label>Reason (optional)</label>
        <textarea className="ss-textarea" rows={3} value={reason} onChange={e => setReason(e.target.value)} />
      </div>
    </Modal>
  );
}
