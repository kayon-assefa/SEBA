import React, { useState } from "react";

export function BarChart({
  data, height = 160, valueFormatter = (n: number) => String(n),
}: {
  data: { label: string; value: number }[];
  height?: number;
  valueFormatter?: (n: number) => string;
}) {
  const [hover, setHover] = useState<number | null>(null);
  const max = Math.max(1, ...data.map(d => d.value));
  const barW = 100 / (data.length * 1.6);
  const gap = barW * 0.6;

  return (
    <div style={{ position: "relative" }}>
      <svg viewBox={`0 0 100 ${height}`} width="100%" height={height} preserveAspectRatio="none" style={{ overflow: "visible" }}>
        {[0, 0.25, 0.5, 0.75, 1].map(f => (
          <line key={f} className="ss-chart-grid" x1="0" x2="100" y1={height - f * (height - 24)} y2={height - f * (height - 24)} />
        ))}
        {data.map((d, i) => {
          const barH = (d.value / max) * (height - 24);
          const x = i * (barW + gap) + gap / 2;
          return (
            <g key={i} onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)}>
              <rect
                className="ss-chart-bar"
                x={x} y={height - 24 - barH} width={barW} height={Math.max(2, barH)} rx={2}
                opacity={hover === null || hover === i ? 1 : 0.45}
              />
              <text className="ss-chart-label" x={x + barW / 2} y={height - 8} textAnchor="middle">{d.label}</text>
            </g>
          );
        })}
      </svg>
      {hover !== null && (
        <div style={{
          position: "absolute", top: 0, left: `${(hover / data.length) * 100}%`,
          background: "var(--text)", color: "var(--bg)", fontSize: 11, fontWeight: 700,
          padding: "3px 8px", borderRadius: 6, transform: "translate(-50%, -110%)", whiteSpace: "nowrap",
        }}>
          {valueFormatter(data[hover].value)}
        </div>
      )}
    </div>
  );
}
