import React, { useState } from "react";
import { Modal } from "./Modal";
import { Tabs } from "./UIKit";
import { useStaff } from "../context/StaffContext";
import { useToast } from "../context/ToastContext";
import { supabase } from "../../../lib/supabase";
import { todayISO } from "../utils/format";

type Kind = "appointment" | "customer" | "order";

export function QuickAddModal({ onClose, onCreated }: { onClose: () => void; onCreated: () => void }) {
  const { staff } = useStaff();
  const toast = useToast();
  const [kind, setKind] = useState<Kind>("appointment");
  const [saving, setSaving] = useState(false);

  const [apt, setApt] = useState({ customer: "", phone: "", service: "", date: todayISO(), time: "09:00" });
  const [cust, setCust] = useState({ name: "", phone: "", email: "" });
  const [ord, setOrd] = useState({ customer_name: "", customer_phone: "", status: "pending", payment_status: "unpaid" });

  async function save() {
    if (!staff) return;
    setSaving(true);
    try {
      if (kind === "appointment") {
        const { error } = await supabase
          .from("appointments")
          .insert({ business_id: staff.business_id, status: "Pending", ...apt });
        if (error) throw error;
      } else if (kind === "customer") {
        const { error } = await supabase.from("customers").insert({ business_id: staff.business_id, ...cust });
        if (error) throw error;
      } else {
        const { error } = await supabase.from("orders").insert({ business_id: staff.business_id, ...ord });
        if (error) throw error;
      }
      onCreated();
      onClose();
    } catch (e: any) {
      toast.show(e.message || "Couldn't save that — try again.", "error");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Modal
      title="Quick add" onClose={onClose}
      footer={<>
        <button className="ss-btn ss-btn-secondary" onClick={onClose}>Cancel</button>
        <button className="ss-btn ss-btn-primary" disabled={saving} onClick={save}>{saving ? "Saving…" : "Save"}</button>
      </>}
    >
      <div style={{ marginBottom: 16 }}>
        <Tabs
          value={kind} onChange={(v: Kind) => setKind(v)}
          options={[
            { value: "appointment", label: "Appointment" },
            { value: "customer", label: "Customer" },
            { value: "order", label: "Order" },
          ] as const}
        />
      </div>

      {kind === "appointment" && (
        <>
          <div className="ss-field"><label>Customer name</label>
            <input className="ss-input" value={apt.customer} onChange={e => setApt({ ...apt, customer: e.target.value })} />
          </div>
          <div className="ss-field"><label>Customer phone</label>
            <input className="ss-input" value={apt.phone} onChange={e => setApt({ ...apt, phone: e.target.value })} />
          </div>
          <div className="ss-field"><label>Service</label>
            <input className="ss-input" value={apt.service} onChange={e => setApt({ ...apt, service: e.target.value })} />
          </div>
          <div style={{ display: "flex", gap: 12 }}>
            <div className="ss-field" style={{ flex: 1 }}><label>Date</label>
              <input type="date" className="ss-input" value={apt.date} onChange={e => setApt({ ...apt, date: e.target.value })} />
            </div>
            <div className="ss-field" style={{ flex: 1 }}><label>Time</label>
              <input type="time" className="ss-input" value={apt.time} onChange={e => setApt({ ...apt, time: e.target.value })} />
            </div>
          </div>
        </>
      )}

      {kind === "customer" && (
        <>
          <div className="ss-field"><label>Name</label>
            <input className="ss-input" value={cust.name} onChange={e => setCust({ ...cust, name: e.target.value })} />
          </div>
          <div className="ss-field"><label>Phone</label>
            <input className="ss-input" value={cust.phone} onChange={e => setCust({ ...cust, phone: e.target.value })} />
          </div>
          <div className="ss-field"><label>Email (optional)</label>
            <input className="ss-input" value={cust.email} onChange={e => setCust({ ...cust, email: e.target.value })} />
          </div>
        </>
      )}

      {kind === "order" && (
        <>
          <div className="ss-field"><label>Customer name</label>
            <input className="ss-input" value={ord.customer_name} onChange={e => setOrd({ ...ord, customer_name: e.target.value })} />
          </div>
          <div className="ss-field"><label>Customer phone</label>
            <input className="ss-input" value={ord.customer_phone} onChange={e => setOrd({ ...ord, customer_phone: e.target.value })} />
          </div>
          <div style={{ display: "flex", gap: 12 }}>
            <div className="ss-field" style={{ flex: 1 }}><label>Status</label>
              <select className="ss-select" value={ord.status} onChange={e => setOrd({ ...ord, status: e.target.value })}>
                {["pending", "preparing", "ready", "delivered", "cancelled"].map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
            <div className="ss-field" style={{ flex: 1 }}><label>Payment</label>
              <select className="ss-select" value={ord.payment_status} onChange={e => setOrd({ ...ord, payment_status: e.target.value })}>
                {["unpaid", "paid", "partial"].map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
          </div>
        </>
      )}
    </Modal>
  );
}
