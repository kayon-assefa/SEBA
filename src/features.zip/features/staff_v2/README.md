# SEBA Staff — v2

A full redesign of the staff module: new design system (light + dark mode,
built from your brand kit), a real component library, live data via Supabase
realtime, a QR "SEBA pass" scanner, in-app + push notifications, and a
handful of new pages (Settings, Scan).

Nothing new to `npm install` — everything is built with React + your existing
`supabase-js` client, no new dependencies.

## 1. Drop the files in

Copy the `staff/` folder over your existing one (it replaces every file from
v1 — nothing is renamed, so your existing imports/routes into this folder
keep working).

## 2. Run the SQL migration

Open `staff_v2_migration.sql` in the Supabase SQL editor and run it once.
It's idempotent (safe to re-run). It adds:

- `qr_code`, `notes`, `is_recurring` to `appointments`
- `items`, `total_amount`, `notes`, `qr_code` to `orders`
- `tags`, `notes` to `customers`
- new tables: `staff_notifications`, `staff_notification_prefs`,
  `push_subscriptions`, `staff_shifts`, `staff_time_off`
- RLS policies scoped to each staff member's business
- triggers that auto-create a notification when a new appointment/order comes in

**Check your real column names first** — the migration assumes the column
names visible in the original v1 code (`customer`, `customer_phone`,
`service`, `date`, `time` on `appointments`; `customer_name`,
`customer_phone` on `orders`). If your actual schema differs, adjust the
`ALTER TABLE` lines before running.

## 3. Routes

Nothing about your router setup changed — `StaffLayout` still expects to sit
behind an authenticated route with an `<Outlet />`, e.g.:

```tsx
import { StaffLayout, StaffDashboard, StaffAppointments, StaffOrders,
         StaffCustomers, StaffSchedule, StaffNotifications, StaffSettings, StaffScan } from "./staff";

<Route path="/staff" element={<StaffLayout />}>
  <Route path="dashboard" element={<StaffDashboard />} />
  <Route path="appointments" element={<StaffAppointments />} />
  <Route path="orders" element={<StaffOrders />} />
  <Route path="customers" element={<StaffCustomers />} />
  <Route path="schedule" element={<StaffSchedule />} />
  <Route path="notifications" element={<StaffNotifications />} />
  <Route path="settings" element={<StaffSettings />} />
  <Route path="scan" element={<StaffScan />} />
</Route>
```

Two routes are new versus v1: `settings` and `scan`.

## 4. The QR "SEBA pass" scanner

Format staff scan against: `SEBA:APPT:<code>` or `SEBA:ORDER:<code>`, where
`<code>` is the `qr_code` column the migration adds to `appointments` /
`orders`. A bare code with no prefix also works (it tries both tables).

You didn't send me the customer-facing app's code, so I can't wire up QR
generation on that side — but as long as whatever generates the customer's
pass encodes one of those two formats using the same `qr_code` value, the
staff scanner will resolve it. If a scanned code doesn't match anything in
this business, staff see a clear "scanned, but not found" screen instead of
an error.

Live camera decoding uses the browser's native `BarcodeDetector` API — works
in Chrome/Edge/Android today, no extra package required. Safari doesn't
support it yet, so on unsupported browsers the page falls back to a manual
code-entry field automatically (nothing breaks, it just skips the live
camera decode). Camera access requires HTTPS (or `localhost` while
developing).

## 5. Push notifications

In-app notifications (the bell, the Notifications page) work immediately
after the SQL migration — no extra setup.

Real *push* notifications (to a phone/desktop even when the tab is closed)
need two more things I can't generate for you automatically:

1. **A VAPID key pair.** Run `npx web-push generate-vapid-keys` once, then
   paste the public key into `staff/utils/push.ts` (`VAPID_PUBLIC_KEY`).
2. **A service worker file** at `/public/seba-staff-sw.js` in your app root:

   ```js
   self.addEventListener("push", (event) => {
     const data = event.data?.json() || {};
     event.waitUntil(
       self.registration.showNotification(data.title || "SEBA", {
         body: data.body || "",
         icon: "/icon.png",
       })
     );
   });
   ```
3. **A sender.** A Supabase Edge Function that reads `push_subscriptions`
   and POSTs to each endpoint (using the `web-push` npm package) whenever
   you want to notify staff. This part is genuinely a small backend job —
   happy to build it if you want, just say so.

Until all three exist, clicking "enable push" in Settings will request
permission and register the service worker, but subscriptions won't
actually receive anything yet — everything else (in-app bell, toasts) works
regardless.

## 6. What's intentionally left out (from your "skip" list)

Clock in/out, CSV export, staff leaderboard, customer ratings display, SMS
reminders, and blocking off unavailable time were all left out this round,
along with 2FA and auto-logout-on-idle. Nothing in the code prevents adding
them later — just say the word.

## 7. Dark mode

Toggle lives in the header (sun/moon icon) and in Settings → Appearance.
Persists per-browser via `localStorage`. It's scoped to `.seba-staff` only,
so it won't affect the rest of your app if this module is embedded inside a
larger site that has its own theme.

## 8. Known limitations, being upfront

- **Customer visit history** in the Customers page matches by name/phone
  against `appointments`, since there's no `customer_id` foreign key in the
  v1 schema. It's good enough for now but a real FK would be more reliable —
  worth a follow-up migration if you want it tightened up.
- **Order line items** (`items` jsonb) is new — existing orders won't have
  any until you start writing them, so the detail modal just shows "no
  itemized line items yet" for old rows.
- I don't have your actual `lib/supabase.ts` or auth/login flow, so
  `StaffLayout`'s sign-out redirects to `/login` — change that path if yours
  is different.
