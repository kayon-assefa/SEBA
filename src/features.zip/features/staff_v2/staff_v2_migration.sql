-- =============================================================================
-- SEBA Staff v2 — Supabase migration
-- =============================================================================
-- Safe to run more than once (everything uses IF NOT EXISTS / ADD COLUMN IF
-- NOT EXISTS). Run this in the Supabase SQL editor, or via `supabase db push`
-- if you keep migrations in a migrations/ folder.
--
-- Assumes these tables already exist from the original app:
--   business_staff(id, user_id, business_id, full_name, email, role, is_active)
--   appointments(id, business_id, customer, customer_phone, service, date, time, status, created_at)
--   orders(id, business_id, customer_name, customer_phone, status, payment_status, created_at)
--   customers(id, business_id, name, phone, email, created_at)
--
-- If your actual column names differ, adjust the ALTER/CREATE statements
-- below before running — check the Table Editor first.
-- =============================================================================

-- ---------- helper: short random code for QR passes ----------
create extension if not exists pgcrypto;

create or replace function seba_short_code() returns text as $$
  select upper(substr(encode(gen_random_bytes(6), 'hex'), 1, 8));
$$ language sql volatile;

-- =============================================================================
-- 1. Appointments — QR pass, notes, recurring flag
-- =============================================================================
alter table appointments add column if not exists qr_code text;
alter table appointments add column if not exists notes text;
alter table appointments add column if not exists is_recurring boolean default false;

update appointments set qr_code = seba_short_code() where qr_code is null;
alter table appointments alter column qr_code set default seba_short_code();
create unique index if not exists appointments_qr_code_key on appointments (qr_code);

-- =============================================================================
-- 2. Orders — line items, total, notes, QR pass
-- =============================================================================
alter table orders add column if not exists items jsonb;              -- [{ "name": "...", "qty": 1, "price": 0 }]
alter table orders add column if not exists total_amount numeric(10,2);
alter table orders add column if not exists notes text;
alter table orders add column if not exists qr_code text;

update orders set qr_code = seba_short_code() where qr_code is null;
alter table orders alter column qr_code set default seba_short_code();
create unique index if not exists orders_qr_code_key on orders (qr_code);

-- =============================================================================
-- 3. Customers — tags, notes (for VIP flags, allergies, preferences, etc.)
-- =============================================================================
alter table customers add column if not exists tags text[] default '{}';
alter table customers add column if not exists notes text;

-- =============================================================================
-- 4. In-app staff notifications
-- =============================================================================
create table if not exists staff_notifications (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null,
  staff_id uuid references business_staff(id) on delete cascade,   -- null = broadcast to whole business
  title text not null,
  body text not null,
  type text not null default 'system' check (type in ('appointment','order','system','reminder')),
  link text,
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists staff_notifications_business_idx on staff_notifications (business_id, created_at desc);
create index if not exists staff_notifications_staff_idx on staff_notifications (staff_id);

alter table staff_notifications enable row level security;

drop policy if exists "staff can read own business notifications" on staff_notifications;
create policy "staff can read own business notifications" on staff_notifications
  for select using (
    business_id in (select business_id from business_staff where user_id = auth.uid() and is_active)
  );

drop policy if exists "staff can update own business notifications" on staff_notifications;
create policy "staff can update own business notifications" on staff_notifications
  for update using (
    business_id in (select business_id from business_staff where user_id = auth.uid() and is_active)
  );

drop policy if exists "staff can insert own business notifications" on staff_notifications;
create policy "staff can insert own business notifications" on staff_notifications
  for insert with check (
    business_id in (select business_id from business_staff where user_id = auth.uid() and is_active)
  );

-- =============================================================================
-- 5. Notification preferences (email / sms / push per staff member)
-- =============================================================================
create table if not exists staff_notification_prefs (
  staff_id uuid primary key references business_staff(id) on delete cascade,
  business_id uuid not null,
  email_enabled boolean not null default true,
  sms_enabled boolean not null default false,
  push_enabled boolean not null default false,
  updated_at timestamptz not null default now()
);

alter table staff_notification_prefs enable row level security;

drop policy if exists "staff manage own prefs" on staff_notification_prefs;
create policy "staff manage own prefs" on staff_notification_prefs
  for all using (
    staff_id in (select id from business_staff where user_id = auth.uid())
  ) with check (
    staff_id in (select id from business_staff where user_id = auth.uid())
  );

-- =============================================================================
-- 6. Push subscriptions (web push endpoints — see utils/push.ts)
-- =============================================================================
create table if not exists push_subscriptions (
  id uuid primary key default gen_random_uuid(),
  staff_id uuid not null references business_staff(id) on delete cascade,
  business_id uuid not null,
  endpoint text not null unique,
  subscription jsonb not null,
  created_at timestamptz not null default now()
);

alter table push_subscriptions enable row level security;

drop policy if exists "staff manage own push subscriptions" on push_subscriptions;
create policy "staff manage own push subscriptions" on push_subscriptions
  for all using (
    staff_id in (select id from business_staff where user_id = auth.uid())
  ) with check (
    staff_id in (select id from business_staff where user_id = auth.uid())
  );

-- =============================================================================
-- 7. Staff shifts (roster)
-- =============================================================================
create table if not exists staff_shifts (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null,
  staff_id uuid not null references business_staff(id) on delete cascade,
  date date not null,
  start_time time not null,
  end_time time not null,
  note text
);
create index if not exists staff_shifts_business_date_idx on staff_shifts (business_id, date);

alter table staff_shifts enable row level security;

drop policy if exists "staff can read own business shifts" on staff_shifts;
create policy "staff can read own business shifts" on staff_shifts
  for select using (
    business_id in (select business_id from business_staff where user_id = auth.uid() and is_active)
  );

drop policy if exists "managers can manage shifts" on staff_shifts;
create policy "managers can manage shifts" on staff_shifts
  for all using (
    business_id in (select business_id from business_staff where user_id = auth.uid() and is_active and role in ('admin','manager'))
  ) with check (
    business_id in (select business_id from business_staff where user_id = auth.uid() and is_active and role in ('admin','manager'))
  );

-- =============================================================================
-- 8. Time-off requests
-- =============================================================================
create table if not exists staff_time_off (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null,
  staff_id uuid not null references business_staff(id) on delete cascade,
  start_date date not null,
  end_date date not null,
  reason text,
  status text not null default 'pending' check (status in ('pending','approved','denied')),
  created_at timestamptz not null default now()
);

alter table staff_time_off enable row level security;

drop policy if exists "staff manage own time off" on staff_time_off;
create policy "staff manage own time off" on staff_time_off
  for all using (
    staff_id in (select id from business_staff where user_id = auth.uid())
    or business_id in (select business_id from business_staff where user_id = auth.uid() and role in ('admin','manager'))
  ) with check (
    staff_id in (select id from business_staff where user_id = auth.uid())
    or business_id in (select business_id from business_staff where user_id = auth.uid() and role in ('admin','manager'))
  );

-- =============================================================================
-- 9. Auto-notify staff when a new appointment/order comes in
-- =============================================================================
create or replace function seba_notify_new_appointment() returns trigger as $$
begin
  insert into staff_notifications (business_id, staff_id, title, body, type, link)
  values (
    new.business_id, null,
    'New appointment', new.customer || ' booked ' || coalesce(new.service, 'a service'),
    'appointment', '/staff/appointments'
  );
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists seba_appointment_notify on appointments;
create trigger seba_appointment_notify
  after insert on appointments
  for each row execute function seba_notify_new_appointment();

create or replace function seba_notify_new_order() returns trigger as $$
begin
  insert into staff_notifications (business_id, staff_id, title, body, type, link)
  values (
    new.business_id, null,
    'New order', coalesce(new.customer_name, 'A customer') || ' placed an order',
    'order', '/staff/orders'
  );
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists seba_order_notify on orders;
create trigger seba_order_notify
  after insert on orders
  for each row execute function seba_notify_new_order();

-- =============================================================================
-- Done. Sanity check:
-- =============================================================================
-- select qr_code from appointments limit 5;
-- select qr_code from orders limit 5;
-- select * from staff_notifications order by created_at desc limit 5;
